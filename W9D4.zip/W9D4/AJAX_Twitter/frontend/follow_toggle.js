
class FollowToggle {
    
    constructor(ele) {
        const $ele = $(ele); //redundant but lazy
        // debugger
        this.$ele = $ele;
        this.userId = $ele.data('user-id');
        this.followState = $ele.data("initial-follow-state");
        this.render();
        this.handleClick();
    }

    render() {
        if (this.followState === "unfollowed") {
            this.$ele.html("Follow!");
        } else {
            this.$ele.html("Unfollow");
        }
    }

    handleClick() {
        this.$ele.on("click", (event) => {
            debugger
            console.log("clicked")
            // event.preventDefault();
            // if (this.followState === unfollowed) {
            //     $.ajax({
            //         method: "POST",
            //         url:`/users/${this.userId}/follow`,
            //         dataType: 'json',
            //         success: response => {
            //             // this.followState = "followed";
            //             // this.render();
            //             console.log("pass")
            //         }
            //     })
            // }else{
            //      $.ajax({
            //         method: "DELETE",
            //         url: `/users/${this.userId}/follow`,
            //         dataType: 'json',
            //         success: response => {
            //             // this.followState = "unfollowed";
            //             // this.render();
            //             console.log("pass")

            //         }
            //     })
            // }
        })
    }




    
    
}
module.exports = FollowToggle;