const FollowToggle = require('./follow_toggle.js')


$(() => {
    // debugger
    const $followToggle = $('button.follow-toggle');
    // debugger
    $('button.follow-toggle').each((index, element) => {
        
        // debugger
        // console.log(index);
        // console.log(element);
        return new FollowToggle(element);
        // debugger
        // console.log("works");
    }); 
})


window.toggle = FollowToggle